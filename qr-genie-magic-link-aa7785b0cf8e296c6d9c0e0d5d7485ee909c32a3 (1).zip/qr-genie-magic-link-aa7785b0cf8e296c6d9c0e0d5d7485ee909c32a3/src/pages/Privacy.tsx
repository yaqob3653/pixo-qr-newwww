import Layout from '@/components/Layout';

const Privacy = () => {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-display font-bold">سياسة الخصوصية</h1>
          <p className="text-xl text-muted-foreground">
            🔒 PixoQR يحترم خصوصيتك بالكامل
          </p>
        </div>

        <div className="prose prose-lg max-w-4xl mx-auto">
          <div className="space-y-6 text-muted-foreground">
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 mb-8">
              <p className="text-primary font-semibold">
                🔒 PixoQR يحترم خصوصيتك بالكامل - جميع العمليات تتم محلياً في متصفحك
              </p>
            </div>

            <p>
              نحن في PixoQR نحترم خصوصيتك ونلتزم بحماية معلوماتك الشخصية. 
              هذه السياسة توضح كيفية تعاملنا مع بياناتك عند استخدام موقعنا.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">1. جمع المعلومات</h2>
            <p>
              موقع PixoQR لا يجمع أو يخزن أي معلومات شخصية نهائياً. جميع عمليات 
              توليد رموز QR تتم محلياً في متصفحك باستخدام JavaScript ولا يتم إرسال 
              أي بيانات إلى خوادمنا أو أي خوادم خارجية.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">2. البيانات المدخلة</h2>
            <p>
              النصوص أو الروابط أو البيانات التي تدخلها لتوليد رموز QR:
            </p>
            <ul className="list-disc list-inside space-y-2 mr-6">
              <li>تبقى في متصفحك فقط ولا تغادره</li>
              <li>لا يتم حفظها أو تسجيلها في أي مكان</li>
              <li>تتم معالجتها محلياً بدون اتصال بالإنترنت</li>
              <li>يتم حذفها تلقائياً عند إغلاق المتصفح</li>
            </ul>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">3. ملفات تعريف الارتباط</h2>
            <p>
              نستخدم ملفات تعريف الارتباط الضرورية فقط لضمان عمل الموقع بشكل صحيح 
              وحفظ تفضيلاتك (مثل الثيم المظلم/الفاتح). لا نستخدم ملفات تعريف الارتباط 
              لتتبع أو تحليل سلوكك أو جمع معلومات شخصية.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">4. مشاركة البيانات</h2>
            <p>
              نحن لا نشارك أي بيانات مع أطراف ثالثة لأننا ببساطة لا نجمع أي بيانات. 
              خصوصيتك مضمونة 100%.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">5. الأمان</h2>
            <p>
              الموقع يستخدم بروتوكول HTTPS المشفر لضمان أمان الاتصال. 
              جميع العمليات تتم في بيئة آمنة ومحمية.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">6. حقوقك</h2>
            <p>
              بما أننا لا نجمع أي بيانات شخصية، فلا يوجد بيانات لحذفها أو تعديلها. 
              أنت تتحكم بالكامل في البيانات التي تدخلها محلياً في متصفحك.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">7. الاتصال بنا</h2>
            <p>
              إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه، يرجى التواصل معنا 
              عبر صفحة الاتصال أو على البريد الإلكتروني: privacy@pixoqr.com
            </p>

            <div className="bg-muted p-6 rounded-lg mt-8">
              <p className="text-sm">
                آخر تحديث: 21 يناير 2025 | PixoQR - أفضل موقع لتوليد رموز QR مجاناً
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Privacy;