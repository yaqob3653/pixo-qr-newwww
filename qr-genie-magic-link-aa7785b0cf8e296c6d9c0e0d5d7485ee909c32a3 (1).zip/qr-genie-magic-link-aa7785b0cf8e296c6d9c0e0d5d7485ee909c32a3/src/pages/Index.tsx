import Layout from '@/components/Layout';
import QRGenerator from '@/components/QRGenerator';
import { QrCode, Zap, Download, Shield, Palette, Globe } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

const Index = () => {
  const { t, language } = useLanguage();
  
  const features = [
    {
      icon: QrCode,
      title: language === 'ar' ? 'توليد فوري' : 'Instant Generation',
      description: language === 'ar' ? 'أنشئ رموز QR في ثوانٍ بضغطة واحدة فقط' : 'Create QR codes in seconds with just one click'
    },
    {
      icon: Palette,
      title: language === 'ar' ? 'أنماط مخصصة' : 'Custom Styles',
      description: language === 'ar' ? 'خصص الألوان والأنماط لتتناسب مع علامتك التجارية' : 'Personalize colors and styles to match your brand'
    },
    {
      icon: Download,
      title: language === 'ar' ? 'تحميل عالي الجودة' : 'High Quality Download',
      description: language === 'ar' ? 'حمل بصيغة PNG أو SVG بدقة عالية' : 'Download in PNG or SVG format in high resolution'
    },
    {
      icon: Shield,
      title: language === 'ar' ? 'يركز على الخصوصية' : 'Privacy Focused',
      description: language === 'ar' ? 'جميع العمليات تتم محلياً - لا يتم حفظ البيانات' : 'All processing happens locally - no data stored'
    },
    {
      icon: Zap,
      title: language === 'ar' ? 'سريع كالبرق' : 'Lightning Fast',
      description: language === 'ar' ? 'محسن للسرعة والأداء' : 'Optimized for speed and performance'
    },
    {
      icon: Globe,
      title: language === 'ar' ? 'توافق شامل' : 'Universal Compatibility',
      description: language === 'ar' ? 'يعمل مع أي رابط أو نص أو صيغة بيانات' : 'Works with any URL, text, or data format'
    }
  ];

  return (
    <Layout>
      <div className="space-y-16">

        {/* Hero Section */}
        <div className="text-center space-y-8 animate-fade-in-up">
          <div className="space-y-6">
            <h1 className="text-5xl md:text-7xl font-display font-bold bg-qr-gradient bg-clip-text text-transparent leading-tight">
              {t('hero.title')}
            </h1>
            <h2 className="text-2xl md:text-3xl text-muted-foreground font-medium">
              {t('hero.subtitle')}
            </h2>
          </div>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-6">
            {t('hero.description')}
          </p>
          
          <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 rounded-xl p-6 max-w-4xl mx-auto">
            <p className="text-base md:text-lg text-foreground font-medium text-center">
              {t('ai.recommendation')}
            </p>
          </div>
        </div>

        {/* QR Generator */}
        {/* ✅ ملاحظة: لتطبيق الظل والحركة على هذا المكون، */}
        {/* اذهب إلى ملف 'QRGenerator.tsx' وأضف كلاس 'main-card' */}
        {/* إلى العنصر الرئيسي (div) بداخله. */}
        <QRGenerator />

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-20">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-2 animate-fade-in-up backdrop-blur-sm bg-glass border border-glass-border"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-8 text-center space-y-4">
                <div className="w-16 h-16 bg-qr-gradient rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                  <feature.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-xl font-display">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* About Section */}
        <div className="text-center space-y-6 py-16">
          <h3 className="text-3xl font-display font-bold">{t('why.choose')}</h3>
          <p className="text-lg text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            {language === 'ar' 
              ? 'PixoQR هو الأداة المثالية لإنشاء رموز QR احترافية بأناقة فائقة. سواء كنت صاحب عمل تريد تطوير موادك التسويقية، أو مطور يحتاج لتوليد QR سريع، أو شخص يريد مشاركة الروابط بطريقة إبداعية - نحن هنا لخدمتك. خيارات التخصيص المتقدمة تتيح لك إنشاء رموز QR تمثل علامتك التجارية حقاً، بينما التزامنا بالخصوصية يضمن أمان بياناتك. والأفضل من ذلك كله، الخدمة مجانية تماماً بدون حدود أو علامات مائية.'
              : 'PixoQR is the perfect tool for creating professional QR codes with exceptional elegance. Whether you are a business owner looking to enhance your marketing materials, a developer who needs quick QR generation, or someone who wants to share links creatively - we are here to serve you. Advanced customization options allow you to create QR codes that truly represent your brand, while our commitment to privacy ensures your data security. Best of all, the service is completely free with no limits or watermarks.'
            }
          </p>
          
          {/* ✅ تم إضافة كلاس 'main-button' هنا لتطبيق الحركة */}
          <div className="main-button bg-primary text-primary-foreground px-8 py-4 rounded-full inline-block font-semibold text-lg hover:bg-primary/90 transition-colors cursor-pointer">
            {t('cta.start')}
          </div>
        </div>

      </div>ش
    </Layout>
  );
};

export default Index;
