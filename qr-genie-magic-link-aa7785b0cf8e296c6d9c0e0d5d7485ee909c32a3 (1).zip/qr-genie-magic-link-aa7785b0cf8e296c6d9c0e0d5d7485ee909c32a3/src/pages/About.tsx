import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { QrCode, Target, Users, Zap } from 'lucide-react';

const About = () => {
  return (
    <Layout>
      <div className="space-y-12 animate-fade-in-up">
        {/* Hero Section */}
        <div className="text-center space-y-6">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            من نحن
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            نحن فريق QRGenie، مطورو أفضل منصة مجانية لتوليد رموز QR عالية الجودة
          </p>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Target className="h-6 w-6 text-primary" />
                رؤيتنا
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                نهدف إلى تبسيط عملية إنشاء رموز QR وجعلها متاحة للجميع مجاناً. 
                نؤمن بأن التكنولوجيا يجب أن تكون بسيطة ومفيدة، ولهذا أنشأنا QRGenie 
                ليكون الحل الأمثل لكل من يحتاج إلى تحويل الروابط والنصوص إلى رموز QR.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <QrCode className="h-6 w-6 text-primary" />
                مهمتنا
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                توفير أداة مجانية وسهلة الاستخدام لإنشاء رموز QR عالية الجودة. 
                نركز على السرعة والجودة والخصوصية، مع ضمان عدم تخزين أو تتبع 
                أي من البيانات التي يدخلها المستخدمون في خدمتنا.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Users className="h-6 w-6 text-primary" />
                فريقنا
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                فريق QRGenie مكون من مطورين ومصممين شغوفين بالتكنولوجيا والابتكار. 
                نعمل باستمرار على تحسين خدمتنا وإضافة ميزات جديدة لتلبية احتياجات 
                مستخدمينا من جميع أنحاء العالم.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Zap className="h-6 w-6 text-primary" />
                لماذا QRGenie؟
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                نختلف عن المنافسين بتركيزنا على البساطة والسرعة. لا نطلب تسجيل، 
                لا نضع علامات مائية، ولا نحد من الاستخدام. خدمتنا مجانية تماماً 
                وتوفر أعلى جودة لرموز QR التي تنشئها.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Statistics */}
        <div className="bg-card rounded-lg p-8 border-0 shadow-lg">
          <h2 className="text-2xl font-bold text-center mb-8">إحصائياتنا</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-primary mb-2">100,000+</div>
              <div className="text-muted-foreground">رمز QR تم إنشاؤه</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">50+</div>
              <div className="text-muted-foreground">دولة تستخدم خدمتنا</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">99.9%</div>
              <div className="text-muted-foreground">نسبة الرضا</div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default About;