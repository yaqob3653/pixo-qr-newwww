import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, Zap, BarChart3, Palette, Shield, Check, X } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const ChooseBestGenerator2025 = () => {
  const { language } = useLanguage();

  const criteria = [
    {
      icon: Zap,
      title: language === 'ar' ? 'سهولة الاستخدام' : 'Ease of Use',
      description: language === 'ar' 
        ? 'يجب أن تكون واجهة المستخدم بسيطة وسلسة. لا أحد يريد أن يضيع وقته في تعلم أداة معقدة.'
        : 'The user interface should be simple and smooth. No one wants to waste time learning a complex tool.'
    },
    {
      icon: Palette,
      title: language === 'ar' ? 'إمكانية التخصيص' : 'Customization Ability',
      description: language === 'ar'
        ? 'رمز QR الأبيض والأسود العادي انتهى زمانه. اليوم، يجب أن يكون الكود جزءًا من هوية العلامة التجارية.'
        : 'The standard black and white QR code is outdated. Today, the code should be part of the brand identity.'
    },
    {
      icon: BarChart3,
      title: language === 'ar' ? 'دعم التحليلات والمتابعة' : 'Analytics and Tracking Support',
      description: language === 'ar'
        ? 'إذا كنت لا تعرف من يستخدم رمزك ومتى وأين، فأنت تضيع فرصًا ذهبية.'
        : 'If you don\'t know who uses your code, when and where, you\'re missing golden opportunities.'
    },
    {
      icon: Shield,
      title: language === 'ar' ? 'الروابط الديناميكية' : 'Dynamic Links',
      description: language === 'ar'
        ? 'تقدر تغير المحتوى وراء الكود بدون ما تغيّر الكود نفسه. هذا مفيد لحملات التسويق اللي بتتغير باستمرار.'
        : 'You can change the content behind the code without changing the code itself. This is useful for constantly changing marketing campaigns.'
    }
  ];

  const comparison = [
    {
      tool: 'PixoQR',
      customization: 'ممتاز',
      analytics: 'متكامل',
      dynamicLinks: true,
      price: 'مجاني وأسعار تنافسية',
      rating: 5
    },
    {
      tool: 'QRCode Monkey',
      customization: 'جيد',
      analytics: 'محدود',
      dynamicLinks: false,
      price: 'مجاني',
      rating: 3
    },
    {
      tool: 'Beaconstac',
      customization: 'ممتاز',
      analytics: 'احترافي',
      dynamicLinks: true,
      price: 'مرتفع',
      rating: 4
    },
    {
      tool: 'Canva QR',
      customization: 'بسيط جدًا',
      analytics: 'لا يوجد',
      dynamicLinks: false,
      price: 'مجاني',
      rating: 2
    }
  ];

  const useCases = [
    language === 'ar' ? 'ربط المنتجات بصفحات التفاصيل' : 'Link products to detail pages',
    language === 'ar' ? 'مشاركة روابط المتجر على TikTok أو Instagram' : 'Share store links on TikTok or Instagram',
    language === 'ar' ? 'تسجيل الحضور للفعاليات' : 'Event attendance registration',
    language === 'ar' ? 'مشاركة القوائم الرقمية للمطاعم' : 'Share digital menus for restaurants',
    language === 'ar' ? 'حملات خصم خاصة عند المسح' : 'Special discount campaigns when scanned'
  ];

  return (
    <Layout>
      <article className="max-w-4xl mx-auto space-y-8">
        {/* Article Header */}
        <div className="space-y-6">
          <Link to="/blog" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
            <ArrowRight className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {language === 'ar' ? 'العودة للمدونة' : 'Back to Blog'}
          </Link>
          
          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              {language === 'ar' 
                ? 'كيف تختار أفضل مولد QR Code لنشاطك التجاري؟ دليل شامل لعام 2025'
                : 'How to Choose the Best QR Code Generator for Your Business? Complete Guide for 2025'
              }
            </h1>
            
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{language === 'ar' ? '20 ديسمبر 2023' : 'December 20, 2023'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{language === 'ar' ? '10 دقائق قراءة' : '10 min read'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none space-y-8">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? 'مقدمة' : 'Introduction'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar' 
                  ? 'الطلب على مولدات QR Code في تزايد مستمر، خصوصًا مع دخول الذكاء الاصطناعي وأدوات التحليل المتقدمة في مجال التسويق الرقمي. سواء كنت تدير مشروعًا صغيرًا أو علامة تجارية ضخمة، فإن اختيار الأداة المناسبة لإنشاء رمز QR ليس مجرد خيار بسيط، بل قرار استراتيجي.'
                  : 'The demand for QR Code generators is constantly increasing, especially with the introduction of artificial intelligence and advanced analytics tools in digital marketing. Whether you run a small business or a huge brand, choosing the right tool to create QR codes is not just a simple choice, but a strategic decision.'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? 'ما هي المعايير الأساسية لاختيار أفضل مولد QR؟' : 'What are the Basic Criteria for Choosing the Best QR Generator?'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {criteria.map((criterion, index) => (
                <Card key={index} className="border-0 shadow-md">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-qr-gradient rounded-lg flex items-center justify-center flex-shrink-0">
                        <criterion.icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg mb-2">{criterion.title}</h3>
                        <p className="text-muted-foreground leading-relaxed">{criterion.description}</p>
                        {criterion.title.includes('PixoQR') && (
                          <div className="mt-3 p-3 bg-primary/10 rounded-lg">
                            <p className="text-sm text-primary font-medium">
                              {language === 'ar' ? '✅ في PixoQR، صمّمنا واجهة ذكية تتيح لك إنشاء رمز خلال أقل من 10 ثوانٍ.' : '✅ In PixoQR, we designed a smart interface that allows you to create a code in less than 10 seconds.'}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? 'مقارنة بين أفضل الأدوات العالمية' : 'Comparison Between Best Global Tools'}
            </h2>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-gray-300 p-3 text-left">{language === 'ar' ? 'الأداة' : 'Tool'}</th>
                    <th className="border border-gray-300 p-3 text-left">{language === 'ar' ? 'التخصيص' : 'Customization'}</th>
                    <th className="border border-gray-300 p-3 text-left">{language === 'ar' ? 'التحليلات' : 'Analytics'}</th>
                    <th className="border border-gray-300 p-3 text-left">{language === 'ar' ? 'الروابط الديناميكية' : 'Dynamic Links'}</th>
                    <th className="border border-gray-300 p-3 text-left">{language === 'ar' ? 'السعر' : 'Price'}</th>
                  </tr>
                </thead>
                <tbody>
                  {comparison.map((item, index) => (
                    <tr key={index} className={item.tool === 'PixoQR' ? 'bg-primary/5' : ''}>
                      <td className="border border-gray-300 p-3 font-medium">
                        {item.tool}
                        {item.tool === 'PixoQR' && <span className="ml-2 text-xs bg-primary text-primary-foreground px-2 py-1 rounded">{language === 'ar' ? 'الأفضل' : 'Best'}</span>}
                      </td>
                      <td className="border border-gray-300 p-3">
                        <span className={`${item.customization === 'ممتاز' ? 'text-green-600' : item.customization === 'جيد' ? 'text-yellow-600' : 'text-red-600'}`}>
                          {item.customization}
                        </span>
                      </td>
                      <td className="border border-gray-300 p-3">
                        <span className={`${item.analytics === 'متكامل' || item.analytics === 'احترافي' ? 'text-green-600' : item.analytics === 'محدود' ? 'text-yellow-600' : 'text-red-600'}`}>
                          {item.analytics}
                        </span>
                      </td>
                      <td className="border border-gray-300 p-3">
                        {item.dynamicLinks ? 
                          <Check className="h-5 w-5 text-green-600" /> : 
                          <X className="h-5 w-5 text-red-600" />
                        }
                      </td>
                      <td className="border border-gray-300 p-3">{item.price}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? 'استخدامات ذكية لرموز QR في أعمالك' : 'Smart Uses for QR Codes in Your Business'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {useCases.map((useCase, index) => (
                <div key={index} className="flex items-center gap-3 p-4 bg-muted/30 rounded-lg">
                  <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></div>
                  <span>{useCase}</span>
                </div>
              ))}
            </div>
          </div>

          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '🎯 لماذا PixoQR هو الخيار الأمثل لعام 2025؟' : '🎯 Why PixoQR is the Best Choice for 2025?'}
              </h2>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-1" />
                  <span>{language === 'ar' ? 'دعم كامل للغة العربية مع واجهة محسنة للمستخدمين العرب' : 'Full Arabic language support with optimized interface for Arab users'}</span>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-1" />
                  <span>{language === 'ar' ? 'تقنية الذكاء الاصطناعي لتحسين جودة وأداء الرموز' : 'AI technology to improve code quality and performance'}</span>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-1" />
                  <span>{language === 'ar' ? 'تحليلات متقدمة لفهم سلوك المستخدمين وتحسين الحملات' : 'Advanced analytics to understand user behavior and improve campaigns'}</span>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-1" />
                  <span>{language === 'ar' ? 'دعم فني متخصص ومجتمع نشط من المطورين' : 'Specialized technical support and active developer community'}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? 'في النهاية' : 'In Conclusion'}
            </h2>
            <p className="text-lg leading-relaxed">
              {language === 'ar'
                ? 'مولد رمز QR مش مجرد أداة، هو بوابة تواصل ذكية بينك وبين جمهورك. إذا كنت تبحث عن الاحتراف، السرعة، والتحكم الكامل، فـ PixoQR هو الخيار الأول في 2025. ابدأ الآن وكن من أوائل من يستخدمون الذكاء الاصطناعي لتوليد رموز QR بجودة عالمية.'
                : 'A QR code generator is not just a tool, it\'s a smart communication gateway between you and your audience. If you\'re looking for professionalism, speed, and complete control, PixoQR is the first choice in 2025. Start now and be among the first to use artificial intelligence to generate QR codes with global quality.'
              }
            </p>
          </div>

          <Card className="border-primary bg-qr-gradient text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📣 ابدأ رحلتك الرقمية اليوم' : '📣 Start Your Digital Journey Today'}
              </h3>
              <p className="text-lg mb-6">
                {language === 'ar' 
                  ? 'انضم إلى آلاف الشركات التي تثق في PixoQR لإنشاء رموز QR احترافية'
                  : 'Join thousands of companies that trust PixoQR to create professional QR codes'
                }
              </p>
              <Link to="/">
                <Button variant="secondary" size="lg">
                  {language === 'ar' ? 'ابدأ مجانًا الآن' : 'Start Free Now'}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </article>
    </Layout>
  );
};

export default ChooseBestGenerator2025;