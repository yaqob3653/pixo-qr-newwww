import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, Check, X, Star } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const BestQrTools2024 = () => {
  const { language } = useLanguage();

  const tools = [
    {
      name: 'PixoQR',
      customization: 'عالي',
      arabicSupport: true,
      download: 'PNG/SVG',
      free: true,
      rating: 5,
      description: language === 'ar' 
        ? 'أداة ذكية قائمة على الذكاء الاصطناعي، تتيح لك إنشاء رموز QR مخصصة بلمسة واحدة.'
        : 'Smart AI-powered tool that allows you to create custom QR codes with one touch.'
    },
    {
      name: 'QR Code Monkey',
      customization: 'متوسط',
      arabicSupport: false,
      download: 'PNG',
      free: true,
      rating: 4,
      description: language === 'ar'
        ? 'أداة عالمية تدعم تخصيص الألوان، الشعار، والأنواع المختلفة من البيانات.'
        : 'Global tool that supports color customization, logos, and different data types.'
    },
    {
      name: 'Unitag QR',
      customization: 'عالي',
      arabicSupport: false,
      download: 'PNG/SVG',
      free: true,
      rating: 4,
      description: language === 'ar'
        ? 'تُستخدم على نطاق واسع في الشركات، وتدعم تخصيص تصميمات QR متقدمة.'
        : 'Widely used in companies, supports advanced QR design customization.'
    },
    {
      name: 'GoQR.me',
      customization: 'بسيط',
      arabicSupport: false,
      download: 'PNG',
      free: true,
      rating: 3,
      description: language === 'ar'
        ? 'أداة بسيطة وسريعة لخلق أكواد نصوص أو روابط. لا تحتاج تسجيل دخول'
        : 'Simple and fast tool for creating text or link codes. No login required'
    }
  ];

  const features = [
    {
      title: language === 'ar' ? 'دعم اللغة العربية والإنجليزية' : 'Arabic and English Support',
      description: language === 'ar' ? 'واجهة كاملة باللغتين مع دعم فني متخصص' : 'Complete interface in both languages with specialized technical support'
    },
    {
      title: language === 'ar' ? 'تخصيص الألوان والشعار والإطار' : 'Color, Logo and Frame Customization',
      description: language === 'ar' ? 'إمكانية تخصيص كاملة لتناسب هوية علامتك التجارية' : 'Complete customization to match your brand identity'
    },
    {
      title: language === 'ar' ? 'روابط متنوعة وملفات PDF' : 'Various Links and PDF Files',
      description: language === 'ar' ? 'دعم جميع أنواع المحتوى الرقمي والملفات' : 'Support for all types of digital content and files'
    },
    {
      title: language === 'ar' ? 'جاهز للطباعة والاستخدام التجاري' : 'Print-Ready and Commercial Use',
      description: language === 'ar' ? 'جودة عالية مناسبة للاستخدام المهني والتجاري' : 'High quality suitable for professional and commercial use'
    }
  ];

  return (
    <Layout>
      <article className="max-w-4xl mx-auto space-y-8">
        {/* Article Header */}
        <div className="space-y-6">
          <Link to="/blog" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
            <ArrowRight className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {language === 'ar' ? 'العودة للمدونة' : 'Back to Blog'}
          </Link>
          
          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              {language === 'ar' 
                ? 'أفضل أدوات تصميم QR Code مجانًا: دليلك الشامل لإنشاء رموز QR احترافية'
                : 'Best Free QR Code Design Tools: Complete Guide to Creating Professional QR Codes'
              }
            </h1>
            
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{language === 'ar' ? '28 ديسمبر 2023' : 'December 28, 2023'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{language === 'ar' ? '8 دقائق قراءة' : '8 min read'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none space-y-8">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📌 مقدمة' : '📌 Introduction'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar' 
                  ? 'في عصر التحول الرقمي، أصبحت رموز QR من الأدوات الأساسية في التسويق، التجارة الإلكترونية، التعليم، وحتى في المطاعم. لكن السؤال: ما هي أفضل الأدوات المجانية لتصميم رموز QR بشكل احترافي وجذاب دون الحاجة إلى خبرة تقنية؟ هذا المقال يضع بين يديك قائمة بأفضل الأدوات المجانية ويوضح كيف تستفيد منها بأقصى طاقتها.'
                  : 'In the era of digital transformation, QR codes have become essential tools in marketing, e-commerce, education, and even in restaurants. But the question is: what are the best free tools for designing QR codes professionally and attractively without needing technical expertise? This article puts in your hands a list of the best free tools and explains how to benefit from them to their fullest potential.'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🧠 ما هو رمز QR ولماذا هو مهم؟' : '🧠 What is QR Code and Why is it Important?'}
            </h2>
            <p className="text-lg leading-relaxed">
              {language === 'ar'
                ? 'رمز QR (Quick Response) هو اختصار سريع للوصول إلى معلومات، روابط، تطبيقات، قوائم طعام، مواقع إلكترونية، وأكثر. يكفي توجيه كاميرا الهاتف إليه لتُفتح لك بوابة معلومات فورية. هذه السرعة والكفاءة جعلت من QR Code أداة لا غنى عنها لأي شخص أو مشروع رقمي.'
                : 'QR code (Quick Response) is a quick shortcut to access information, links, applications, food menus, websites, and more. Just point your phone camera at it to open an instant information gateway. This speed and efficiency made QR Code an indispensable tool for any person or digital project.'
              }
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🔥 أفضل أدوات تصميم QR Code مجاناً:' : '🔥 Best Free QR Code Design Tools:'}
            </h2>
            
            <div className="space-y-6">
              {tools.map((tool, index) => (
                <Card key={index} className={`${tool.name === 'PixoQR' ? 'border-primary border-2 bg-primary/5' : ''}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                          {tool.name}
                          {tool.name === 'PixoQR' && <Star className="h-5 w-5 text-yellow-500" />}
                        </h3>
                        <div className="flex items-center gap-2 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${i < tool.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                            />
                          ))}
                        </div>
                      </div>
                      {tool.name === 'PixoQR' && (
                        <div className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                          {language === 'ar' ? 'الأفضل' : 'Best Choice'}
                        </div>
                      )}
                    </div>
                    
                    <p className="text-muted-foreground mb-4">{tool.description}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="font-medium">{language === 'ar' ? 'التخصيص:' : 'Customization:'}</span>
                        <span className={`ml-2 ${tool.customization === 'عالي' ? 'text-green-600' : tool.customization === 'متوسط' ? 'text-yellow-600' : 'text-red-600'}`}>
                          {tool.customization}
                        </span>
                      </div>
                      <div>
                        <span className="font-medium">{language === 'ar' ? 'العربية:' : 'Arabic:'}</span>
                        {tool.arabicSupport ? 
                          <Check className="h-4 w-4 text-green-600 inline ml-2" /> : 
                          <X className="h-4 w-4 text-red-600 inline ml-2" />
                        }
                      </div>
                      <div>
                        <span className="font-medium">{language === 'ar' ? 'التحميل:' : 'Download:'}</span>
                        <span className="ml-2">{tool.download}</span>
                      </div>
                      <div>
                        <span className="font-medium">{language === 'ar' ? 'مجاني:' : 'Free:'}</span>
                        {tool.free ? 
                          <Check className="h-4 w-4 text-green-600 inline ml-2" /> : 
                          <X className="h-4 w-4 text-red-600 inline ml-2" />
                        }
                      </div>
                    </div>
                    
                    {tool.name === 'PixoQR' && (
                      <Link to="/">
                        <Button className="w-full mt-4">
                          {language === 'ar' ? 'جربه الآن' : 'Try It Now'}
                        </Button>
                      </Link>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '💼 كيف تختار الأداة المناسبة لك؟' : '💼 How to Choose the Right Tool for You?'}
            </h2>
            
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-green-800">
                  <strong>{language === 'ar' ? 'إذا كنت تبحث عن تصميم عربي احترافي مع دعم فني:' : 'If you want professional Arabic design with technical support:'}</strong> {language === 'ar' ? 'اختر PixoQR' : 'Choose PixoQR'}
                </p>
              </div>
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-blue-800">
                  <strong>{language === 'ar' ? 'إذا كان مشروعك بسيط أو تجريبي:' : 'If your project is simple or experimental:'}</strong> {language === 'ar' ? 'استخدم QR Monkey أو GoQR' : 'Use QR Monkey or GoQR'}
                </p>
              </div>
              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <p className="text-purple-800">
                  <strong>{language === 'ar' ? 'إذا كنت شركة وتحتاج علامة تجارية مخصصة:' : 'If you are a company needing custom branding:'}</strong> {language === 'ar' ? 'جرّب Unitag' : 'Try Unitag'}
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🌟 مميزات PixoQR التي تجعله الأفضل:' : '🌟 PixoQR Features That Make It the Best:'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <Card key={index} className="border-0 shadow-md">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-lg mb-2 text-primary">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '🧠 نصيحة خبير:' : '🧠 Expert Tip:'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar'
                  ? 'قم دائمًا باستخدام رموز QR مخصصة بدل الشكل العادي الأبيض والأسود. أضف شعار علامتك التجارية، واستخدم روابط مختصرة وقابلة للتتبع (trackable). هذا يعزز من ثقة المستخدم ويزيد من معدل التحويل.'
                  : 'Always use custom QR codes instead of the standard black and white format. Add your brand logo, and use shortened and trackable links. This enhances user trust and increases conversion rates.'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🏁 الخلاصة:' : '🏁 Conclusion:'}
            </h2>
            <p className="text-lg leading-relaxed">
              {language === 'ar'
                ? 'إذا كنت جادًا في استخدام رمز QR لتحسين وصول جمهورك، فاختيار الأداة المناسبة أمر حاسم. PixoQR يقدّم لك تجربة متكاملة مجانية، تدعم اللغة العربية وتضمن تصاميم عالية الجودة. ابدأ اليوم بإنشاء أول رمز QR احترافي خاص بك، وادخل عالم الذكاء الرقمي بثقة!'
                : 'If you are serious about using QR codes to improve your audience reach, choosing the right tool is crucial. PixoQR offers you a complete free experience, supports Arabic language and ensures high-quality designs. Start today by creating your first professional QR code, and enter the world of digital intelligence with confidence!'
              }
            </p>
          </div>

          <Card className="border-primary bg-qr-gradient text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📣 دعوة للفعل' : '📣 Call to Action'}
              </h3>
              <p className="text-lg mb-6">
                {language === 'ar' 
                  ? 'ابدأ الآن وكن من أوائل من يستخدمون الذكاء الاصطناعي لتوليد رموز QR بجودة عالمية.'
                  : 'Start now and be among the first to use artificial intelligence to generate QR codes with global quality.'
                }
              </p>
              <Link to="/">
                <Button variant="secondary" size="lg">
                  {language === 'ar' ? 'جرب PixoQR الآن' : 'Try PixoQR Now'}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </article>
    </Layout>
  );
};

export default BestQrTools2024;