import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, User, Mail, Phone, MapPin } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const SmartBusinessCard = () => {
  const { language } = useLanguage();

  const steps = [
    {
      title: language === 'ar' ? 'ادخل على موقع PixoQR' : 'Go to PixoQR Website',
      description: language === 'ar' ? 'واجهة سهلة وسريعة — لا تحتاج أي تسجيل.' : 'Easy and fast interface — no registration needed.'
    },
    {
      title: language === 'ar' ? 'اختر نوع المعلومات' : 'Choose Information Type',
      description: language === 'ar' ? 'حدد أنك تريد إنشاء QR لبطاقة تعريف (vCard أو رابط صفحة شخصية).' : 'Select that you want to create QR for business card (vCard or personal page link).'
    },
    {
      title: language === 'ar' ? 'أدخل بياناتك المهنية' : 'Enter Your Professional Data',
      description: language === 'ar' ? 'املأ الحقول المطلوبة: الاسم، البريد، الوظيفة، وسائل التواصل… إلخ.' : 'Fill required fields: name, email, job title, social media... etc.'
    },
    {
      title: language === 'ar' ? 'خصّص التصميم' : 'Customize Design',
      description: language === 'ar' ? 'غيّر ألوان الكود، أضف شعار شركتك، واختر الشكل المناسب.' : 'Change code colors, add your company logo, and choose suitable shape.'
    },
    {
      title: language === 'ar' ? 'حمّل الكود وابدأ الاستخدام' : 'Download Code and Start Using',
      description: language === 'ar' ? 'يمكنك طباعته، أو وضعه في توقيع بريدك الإلكتروني، أو على موقعك الشخصي.' : 'You can print it, put it in your email signature, or on your personal website.'
    }
  ];

  const useCases = [
    { icon: Mail, text: language === 'ar' ? 'في توقيع الإيميل' : 'In email signature' },
    { icon: User, text: language === 'ar' ? 'على الكرت الشخصي الورقي' : 'On paper business card' },
    { icon: Phone, text: language === 'ar' ? 'على لابتوبك أو هاتفك كملصق' : 'On laptop or phone as sticker' },
    { icon: MapPin, text: language === 'ar' ? 'على LinkedIn أو مواقع العمل الحر' : 'On LinkedIn or freelance sites' }
  ];

  return (
    <Layout>
      <article className="max-w-4xl mx-auto space-y-8">
        {/* Article Header */}
        <div className="space-y-6">
          <Link to="/blog" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
            <ArrowRight className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {language === 'ar' ? 'العودة للمدونة' : 'Back to Blog'}
          </Link>
          
          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              {language === 'ar' 
                ? 'بطاقة العمل الذكية: كيف تنشئ بطاقة تعريف احترافية برمز QR باستخدام PixoQR؟'
                : 'Smart Business Card: How to Create Professional QR Business Cards with PixoQR'
              }
            </h1>
            
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{language === 'ar' ? '5 يناير 2024' : 'January 5, 2024'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{language === 'ar' ? '6 دقائق قراءة' : '6 min read'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none space-y-8">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📌 المقدمة' : '📌 Introduction'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar' 
                  ? 'في الاجتماعات، المعارض، والمناسبات المهنية، أول انطباع تتركه مهم جدًا. لكن بدلًا من توزيع بطاقات ورقية تنتهي غالبًا في سلة المهملات، أصبح الحل الذكي هو بطاقة العمل الرقمية باستخدام QR Code. باستخدام PixoQR، يمكنك إنشاء بطاقة تعريف رقمية احترافية خلال دقائق — بدون برامج تصميم معقدة أو طباعة.'
                  : 'In meetings, exhibitions, and professional events, the first impression you leave is very important. But instead of distributing paper cards that often end up in the trash, the smart solution is a digital business card using QR Code. Using PixoQR, you can create a professional digital business card in minutes — without complex design software or printing.'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '💼 ما هي بطاقة العمل الذكية؟' : '💼 What is a Smart Business Card?'}
            </h2>
            <p className="text-lg leading-relaxed mb-6">
              {language === 'ar'
                ? 'هي رمز QR يحتوي على معلوماتك المهنية: الاسم، الوظيفة، البريد الإلكتروني، رقم الهاتف، روابط السوشيال ميديا، الموقع الجغرافي، صورة شخصية أو لوجو شركتك. المتلقي ببساطة يمسح الكود ويصل إلى صفحة أنيقة بجميع بياناتك، يمكنه حفظها بنقرة واحدة.'
                : 'It is a QR code that contains your professional information: name, job title, email, phone number, social media links, location, personal photo or company logo. The recipient simply scans the code and reaches an elegant page with all your data, which can be saved with one click.'
              }
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <User className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm font-medium">{language === 'ar' ? 'الاسم' : 'Name'}</p>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <Mail className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm font-medium">{language === 'ar' ? 'البريد' : 'Email'}</p>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <Phone className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm font-medium">{language === 'ar' ? 'الهاتف' : 'Phone'}</p>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <MapPin className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm font-medium">{language === 'ar' ? 'الموقع' : 'Location'}</p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🔧 خطوات إنشاء بطاقة عمل احترافية باستخدام PixoQR:' : '🔧 Steps to Create Professional Business Card Using PixoQR:'}
            </h2>
            
            <div className="space-y-6">
              {steps.map((step, index) => (
                <Card key={index} className="border-l-4 border-l-primary">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold flex-shrink-0">
                        {index + 1}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                        <p className="text-muted-foreground">{step.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🎯 أين تستخدم بطاقة العمل الرقمية؟' : '🎯 Where to Use Digital Business Card?'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {useCases.map((useCase, index) => (
                <div key={index} className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                  <useCase.icon className="h-6 w-6 text-primary flex-shrink-0" />
                  <span className="font-medium">{useCase.text}</span>
                </div>
              ))}
            </div>
          </div>

          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '🧠 مميزات بطاقات العمل الرقمية:' : '🧠 Digital Business Card Advantages:'}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <span className="text-green-500 font-bold">✔️</span>
                    <span>{language === 'ar' ? 'لا تضيع ولا تتلف' : 'Never lost or damaged'}</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="text-green-500 font-bold">✔️</span>
                    <span>{language === 'ar' ? 'سهلة التحديث' : 'Easy to update'}</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <span className="text-green-500 font-bold">✔️</span>
                    <span>{language === 'ar' ? 'مناسبة للعمل عن بعد' : 'Perfect for remote work'}</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="text-green-500 font-bold">✔️</span>
                    <span>{language === 'ar' ? 'تواكب العصر وتعكس احترافك' : 'Modern and reflects professionalism'}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🟩 خلاصة:' : '🟩 Conclusion:'}
            </h2>
            <p className="text-lg leading-relaxed">
              {language === 'ar'
                ? 'البطاقات الورقية لم تعد تكفي في عالم الأعمال الرقمي. باستخدام PixoQR، تقدر تنشئ بطاقة عمل احترافية خلال دقائق — بتصميم جذاب، وسهولة مشاركة، وتوفير في الوقت والمال.'
                : 'Paper cards are no longer sufficient in the digital business world. Using PixoQR, you can create a professional business card in minutes — with attractive design, easy sharing, and saving time and money.'
              }
            </p>
          </div>

          <Card className="border-primary bg-qr-gradient text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📣 دعوة للفعل' : '📣 Call to Action'}
              </h3>
              <div className="space-y-3 text-lg">
                <p>{language === 'ar' ? '🎯 أنشئ بطاقتك الرقمية الآن مجانًا' : '🎯 Create your digital card now for free'}</p>
                <p>{language === 'ar' ? 'ابدأ بمشاركة بياناتك باحترافية' : 'Start sharing your data professionally'}</p>
                <p>{language === 'ar' ? 'واكسب الانطباع الأول قبل أي منافس!' : 'And make a first impression before any competitor!'}</p>
              </div>
              <Link to="/">
                <Button variant="secondary" size="lg" className="mt-6">
                  {language === 'ar' ? 'ابدأ الآن' : 'Start Now'}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </article>
    </Layout>
  );
};

export default SmartBusinessCard;