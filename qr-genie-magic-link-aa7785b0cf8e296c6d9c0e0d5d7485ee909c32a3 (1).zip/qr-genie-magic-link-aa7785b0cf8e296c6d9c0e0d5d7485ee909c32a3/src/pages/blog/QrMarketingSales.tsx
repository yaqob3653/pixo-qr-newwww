import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, TrendingUp, Target, Zap, BarChart3 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const QrMarketingSales = () => {
  const { language } = useLanguage();

  const marketingIdeas = [
    {
      title: language === 'ar' ? 'QR لعروض محدودة' : 'QR for Limited Offers',
      description: language === 'ar' 
        ? 'أنشئ رمز QR يحتوي على عرض خاص أو كوبون خصم.'
        : 'Create a QR code with special offers or discount coupons.',
      example: language === 'ar' 
        ? 'مثال: رابط إلى صفحة "اشترِ منتجين واحصل على الثالث مجانًا"'
        : 'Example: Link to "Buy 2 Get 1 Free" page',
      icon: Target
    },
    {
      title: language === 'ar' ? 'QR لحسابات التواصل' : 'QR for Social Media',
      description: language === 'ar'
        ? 'اجعل الناس يتابعوك بضغطة واحدة. أنشئ QR لحسابك على إنستغرام أو TikTok.'
        : 'Make people follow you with one click. Create QR for your Instagram or TikTok account.',
      example: language === 'ar'
        ? 'أضف شعارك داخل الكود من خلال PixoQR ليبقى متناسقًا مع الهوية البصرية.'
        : 'Add your logo inside the code through PixoQR to keep it consistent with your visual identity.',
      icon: TrendingUp
    },
    {
      title: language === 'ar' ? 'QR لمنتجات محددة' : 'QR for Specific Products',
      description: language === 'ar'
        ? 'ضع كود QR على المنتج نفسه، يؤدي إلى فيديو يشرح استخدامه، أو صفحة تقييمات العملاء.'
        : 'Place QR code on the product itself, leading to a video explaining its use, or customer reviews page.',
      example: language === 'ar'
        ? 'هذا يعزز الثقة ويُحفز قرار الشراء بسرعة.'
        : 'This builds trust and encourages quick purchase decisions.',
      icon: BarChart3
    }
  ];

  return (
    <Layout>
      <article className="max-w-4xl mx-auto space-y-8">
        {/* Article Header */}
        <div className="space-y-6">
          <Link to="/blog" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
            <ArrowRight className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {language === 'ar' ? 'العودة للمدونة' : 'Back to Blog'}
          </Link>
          
          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              {language === 'ar' 
                ? 'كيف يمكن لرموز QR أن تُضاعف مبيعاتك؟ استخدم PixoQR بذكاء في التسويق'
                : 'How QR Codes Can Double Your Sales? Smart Marketing with PixoQR'
              }
            </h1>
            
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{language === 'ar' ? '10 يناير 2024' : 'January 10, 2024'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{language === 'ar' ? '7 دقائق قراءة' : '7 min read'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none space-y-8">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📌 المقدمة' : '📌 Introduction'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar' 
                  ? 'في عالم التسويق الحديث، لم يعد من الضروري صرف آلاف الدولارات على الحملات الإعلانية لتحقق نتائج ملموسة. التقنية تغيّر كل شيء، ومن أقوى الأدوات التي أثبتت فعاليتها في السنوات الأخيرة هي رموز QR. إذا كنت لا تزال تعتبر QR أداة جانبية، فأنت تفوّت فرصًا ضخمة. والأهم؟ أنك لست بحاجة لأي أدوات مدفوعة — فقط استخدم PixoQR وابدأ حملة تسويق رقمية بذكاء وبدون تكلفة.'
                  : 'In modern marketing, it\'s no longer necessary to spend thousands of dollars on advertising campaigns to achieve tangible results. Technology changes everything, and one of the most powerful tools that has proven effective in recent years is QR codes. If you still consider QR a side tool, you\'re missing huge opportunities. More importantly? You don\'t need any paid tools — just use PixoQR and start a smart digital marketing campaign at no cost.'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '📊 لماذا رموز QR تغيّر قواعد التسويق؟' : '📊 Why QR Codes Change Marketing Rules?'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Zap className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">
                      {language === 'ar' ? 'سهولة التفاعل' : 'Easy Interaction'}
                    </h3>
                    <p className="text-muted-foreground">
                      {language === 'ar'
                        ? 'العملاء يمسحون الكود بجوالهم وينتقلون فورًا إلى موقعك أو عرضك.'
                        : 'Customers scan the code with their phones and instantly go to your website or offer.'
                      }
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <BarChart3 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">
                      {language === 'ar' ? 'نتائج قابلة للقياس' : 'Measurable Results'}
                    </h3>
                    <p className="text-muted-foreground">
                      {language === 'ar'
                        ? 'باستخدام أدوات تحليلات، يمكنك تتبع كم من الأشخاص تفاعلوا مع الكود.'
                        : 'Using analytics tools, you can track how many people interacted with the code.'
                      }
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Target className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">
                      {language === 'ar' ? 'مرونة الاستخدام' : 'Usage Flexibility'}
                    </h3>
                    <p className="text-muted-foreground">
                      {language === 'ar'
                        ? 'على الملصقات، الكروت، المنتجات، البريد الإلكتروني، الإعلانات المطبوعة… في كل مكان.'
                        : 'On stickers, cards, products, emails, printed ads… everywhere.'
                      }
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <TrendingUp className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">
                      {language === 'ar' ? 'تكلفة شبه صفرية' : 'Near-Zero Cost'}
                    </h3>
                    <p className="text-muted-foreground">
                      {language === 'ar'
                        ? 'بدلاً من إعلانات مدفوعة، أنشئ QR ووزّعه بطرق مبتكرة وذكية.'
                        : 'Instead of paid ads, create QR and distribute it in innovative and smart ways.'
                      }
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🚀 كيف تستخدم PixoQR لزيادة مبيعاتك؟' : '🚀 How to Use PixoQR to Increase Sales?'}
            </h2>
            
            <div className="space-y-8">
              {marketingIdeas.map((idea, index) => (
                <Card key={index} className="border-l-4 border-l-primary">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-qr-gradient rounded-lg flex items-center justify-center flex-shrink-0">
                        <idea.icon className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold mb-3">
                          {language === 'ar' ? `📌 الفكرة ${index + 1}: ` : `📌 Idea ${index + 1}: `}
                          {idea.title}
                        </h3>
                        <p className="text-lg mb-3">{idea.description}</p>
                        <div className="bg-muted/50 p-4 rounded-lg">
                          <p className="text-sm text-muted-foreground">
                            <strong>{language === 'ar' ? '🔗 مثال: ' : '🔗 Example: '}</strong>
                            {idea.example}
                          </p>
                        </div>
                        <p className="text-sm text-muted-foreground mt-3">
                          {language === 'ar' 
                            ? '🎯 ضع الكود على واجهات المحلات، داخل الطرود، أو على الستوري في إنستغرام.'
                            : '🎯 Place the code on store fronts, inside packages, or on Instagram stories.'
                          }
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '🧠 نصيحة للمحترفين:' : '🧠 Professional Tip:'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar'
                  ? 'إذا كنت تستخدم PixoQR بشكل متكرر في حملاتك، غيّر تصميم الرمز في كل حملة (لون مختلف، شكل مختلف) حتى تتبع التفاعل وتُميز الأداء. أيضًا، استخدم خدمة اختصار الروابط قبل إنشاء الكود للحصول على تحليلات دقيقة (مثل Bit.ly أو Rebrandly).'
                  : 'If you use PixoQR frequently in your campaigns, change the code design in each campaign (different color, different shape) to track interaction and distinguish performance. Also, use a link shortening service before creating the code to get accurate analytics (like Bit.ly or Rebrandly).'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🟩 خلاصة:' : '🟩 Conclusion:'}
            </h2>
            <p className="text-lg leading-relaxed">
              {language === 'ar'
                ? 'QR ليس مجرّد مربع أبيض وأسود. إنه سلاح تسويقي إذا عرفت كيف تستغله. مع أدوات مثل PixoQR، يمكنك تصميم رموز جذابة، مخصصة، وتعمل على زيادة مبيعاتك دون أي خبرة تقنية أو ميزانية ضخمة.'
                : 'QR is not just a black and white square. It\'s a marketing weapon if you know how to leverage it. With tools like PixoQR, you can design attractive, customized codes that increase your sales without any technical expertise or huge budget.'
              }
            </p>
          </div>

          <Card className="border-primary bg-qr-gradient text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📣 دعوة للفعل' : '📣 Call to Action'}
              </h3>
              <div className="space-y-3 text-lg">
                <p>{language === 'ar' ? '🔗 أنشئ كود خصم الآن باستخدام PixoQR' : '🔗 Create a discount code now using PixoQR'}</p>
                <p>{language === 'ar' ? '📈 استخدمه في حملتك القادمة وشاهد الفرق في التفاعل والمبيعات' : '📈 Use it in your next campaign and see the difference in engagement and sales'}</p>
                <p>{language === 'ar' ? '🎯 لا تأخذ رأينا، جربه بنفسك' : '🎯 Don\'t take our word for it, try it yourself'}</p>
              </div>
              <Link to="/">
                <Button variant="secondary" size="lg" className="mt-6">
                  {language === 'ar' ? 'ابدأ الآن' : 'Start Now'}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </article>
    </Layout>
  );
};

export default QrMarketingSales;