import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, QrCode, Palette, Download, Shield } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const BestQrGuide = () => {
  const { language } = useLanguage();

  const features = [
    {
      icon: QrCode,
      title: language === 'ar' ? 'واجهة بسيطة وسريعة' : 'Simple and Fast Interface',
      description: language === 'ar' 
        ? 'بدون تسجيل، بدون تعقيد، فقط أدخل الرابط أو المحتوى واحصل على QR جاهز.'
        : 'No registration, no complexity, just enter the link or content and get a ready QR code.'
    },
    {
      icon: Palette,
      title: language === 'ar' ? 'تصميم قابل للتخصيص' : 'Customizable Design',
      description: language === 'ar'
        ? 'اختر الألوان، شكل الحواف، أضف شعارك، وغير ذلك.'
        : 'Choose colors, edge shapes, add your logo, and more.'
    },
    {
      icon: Shield,
      title: language === 'ar' ? 'آمن ومجاني 100%' : '100% Safe and Free',
      description: language === 'ar'
        ? 'لا يجمع بياناتك ولا يُجبرك على الاشتراك.'
        : 'Does not collect your data and does not force you to subscribe.'
    },
    {
      icon: Download,
      title: language === 'ar' ? 'جاهز للأعمال التجارية' : 'Business Ready',
      description: language === 'ar'
        ? 'مثالي للشركات الناشئة، المبرمجين، المطاعم، المدارس، والمزيد.'
        : 'Perfect for startups, developers, restaurants, schools, and more.'
    }
  ];

  return (
    <Layout>
      <article className="max-w-4xl mx-auto space-y-8">
        {/* Article Header */}
        <div className="space-y-6">
          <Link to="/blog" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
            <ArrowRight className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {language === 'ar' ? 'العودة للمدونة' : 'Back to Blog'}
          </Link>
          
          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              {language === 'ar' 
                ? 'أفضل طريقة لإنشاء رموز QR احترافية مجانًا: دليلك لاستخدام PixoQR'
                : 'Best Way to Create Professional QR Codes for Free: Your Guide to Using PixoQR'
              }
            </h1>
            
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{language === 'ar' ? '15 يناير 2024' : 'January 15, 2024'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{language === 'ar' ? '5 دقائق قراءة' : '5 min read'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none space-y-8">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📌 المقدمة' : '📌 Introduction'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar' 
                  ? 'في عالم رقمي سريع ومتطور، أصبحت رموز QR وسيلة أساسية للربط بين المحتوى الرقمي والعالم الواقعي. سواء كنت صاحب مشروع، مطور، أو حتى طالب، فإن امتلاك أداة قوية وسهلة لتوليد رموز QR يمكن أن يوفر عليك وقتًا وجهدًا كبيرًا. وهنا يأتي دور PixoQR كأفضل موقع مجاني لإنشاء رموز QR احترافية خلال ثوانٍ.'
                  : 'In a fast-paced digital world, QR codes have become an essential tool for bridging digital content with the real world. Whether you are a business owner, developer, or student, having a powerful and easy tool for generating QR codes can save you significant time and effort. This is where PixoQR comes in as the best free website for creating professional QR codes in seconds.'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🔧 لماذا تحتاج إلى رمز QR؟' : '🔧 Why Do You Need QR Codes?'}
            </h2>
            <p className="text-lg leading-relaxed mb-6">
              {language === 'ar'
                ? 'رمز الاستجابة السريعة (QR Code) ليس فقط رابطًا بصريًا — بل هو جسر سريع وفعّال لتوجيه المستخدمين إلى مواقع إلكترونية، حسابات تواصل اجتماعي، نماذج، ملفات PDF، بطاقات أعمال، أو حتى إعدادات Wi-Fi.'
                : 'A Quick Response (QR) Code is not just a visual link — it is a fast and effective bridge to direct users to websites, social media accounts, forms, PDF files, business cards, or even Wi-Fi settings.'
              }
            </p>
            
            <h3 className="text-xl font-semibold mb-4">
              {language === 'ar' ? 'استخدامات QR في حياتك:' : 'QR Uses in Your Life:'}
            </h3>
            <ul className="space-y-3 text-lg">
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold">•</span>
                <span>{language === 'ar' ? 'قوائم الطعام الرقمية في المطاعم' : 'Digital menus in restaurants'}</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold">•</span>
                <span>{language === 'ar' ? 'بطاقات العمل الإلكترونية' : 'Electronic business cards'}</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold">•</span>
                <span>{language === 'ar' ? 'روابط الدفع السريع' : 'Quick payment links'}</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold">•</span>
                <span>{language === 'ar' ? 'التسويق عبر الإنترنت' : 'Online marketing'}</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold">•</span>
                <span>{language === 'ar' ? 'حملات إعلانية على الطرق' : 'Road advertising campaigns'}</span>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🚀 مميزات PixoQR التي تجعله يتفوّق على المنافسين:' : '🚀 PixoQR Features That Make It Superior:'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <Card key={index} className="border-0 shadow-md">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-qr-gradient rounded-lg flex items-center justify-center flex-shrink-0">
                        <feature.icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                        <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🎯 كيف تستخدم موقع PixoQR خطوة بخطوة:' : '🎯 How to Use PixoQR Step by Step:'}
            </h2>
            <ol className="space-y-4 text-lg">
              <li className="flex gap-4">
                <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold flex-shrink-0">1</span>
                <span>{language === 'ar' ? 'ادخل على pixoqr.com' : 'Go to pixoqr.com'}</span>
              </li>
              <li className="flex gap-4">
                <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold flex-shrink-0">2</span>
                <span>{language === 'ar' ? 'اختر نوع البيانات (رابط، نص، رقم، Wi-Fi، إلخ)' : 'Choose data type (link, text, number, Wi-Fi, etc.)'}</span>
              </li>
              <li className="flex gap-4">
                <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold flex-shrink-0">3</span>
                <span>{language === 'ar' ? 'أدخل المحتوى الخاص بك' : 'Enter your content'}</span>
              </li>
              <li className="flex gap-4">
                <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold flex-shrink-0">4</span>
                <span>{language === 'ar' ? 'عدّل التصميم والألوان حسب رغبتك' : 'Customize design and colors as desired'}</span>
              </li>
              <li className="flex gap-4">
                <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold flex-shrink-0">5</span>
                <span>{language === 'ar' ? 'حمّل الرمز بجودة عالية (PNG, SVG)' : 'Download the code in high quality (PNG, SVG)'}</span>
              </li>
            </ol>
          </div>

          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '🧠 نصيحة SEO من خبير:' : '🧠 SEO Expert Tip:'}
              </h2>
              <p className="text-lg leading-relaxed">
                {language === 'ar'
                  ? 'استخدم رمز QR الخاص بك في توقيع الإيميل، على أغلفة المنتجات، وفي السوشيال ميديا، ولا تنسَ أن تضعه على Google Business Profile!'
                  : 'Use your QR code in email signatures, on product covers, and on social media, and don\'t forget to put it on your Google Business Profile!'
                }
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">
              {language === 'ar' ? '🟩 خلاصة:' : '🟩 Conclusion:'}
            </h2>
            <p className="text-lg leading-relaxed">
              {language === 'ar'
                ? 'سواء كنت محترفًا في عالم الأعمال أو هاويًا يبحث عن أدوات ذكية، فإن PixoQR يمنحك القوة والمرونة لإنشاء رموز QR احترافية بدون أي تكلفة. لا تضيع وقتك مع أدوات قديمة ومعقدة — جرب PixoQR اليوم وابدأ في ربط العالم من حولك بنقرة واحدة!'
                : 'Whether you are a business professional or an enthusiast looking for smart tools, PixoQR gives you the power and flexibility to create professional QR codes at no cost. Don\'t waste your time with old and complex tools — try PixoQR today and start connecting the world around you with just one click!'
              }
            </p>
          </div>

          <Card className="border-primary bg-qr-gradient text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? '📣 دعوة للفعل' : '📣 Call to Action'}
              </h3>
              <div className="space-y-3 text-lg">
                <p>{language === 'ar' ? '✅ جرب الآن PixoQR مجانًا' : '✅ Try PixoQR Now for Free'}</p>
                <p>{language === 'ar' ? '⬅️ أنشئ رمزك خلال 10 ثوانٍ فقط!' : '⬅️ Create your code in just 10 seconds!'}</p>
                <p>{language === 'ar' ? '🔒 لا حاجة لتسجيل – مجاني وآمن بالكامل!' : '🔒 No registration needed – completely free and secure!'}</p>
              </div>
              <Link to="/">
                <Button variant="secondary" size="lg" className="mt-6">
                  {language === 'ar' ? 'ابدأ الآن' : 'Start Now'}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </article>
    </Layout>
  );
};

export default BestQrGuide;