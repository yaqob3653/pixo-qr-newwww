import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Calendar, ArrowLeft } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const BlogIndex = () => {
  const { t, language } = useLanguage();

  const blogPosts = [
    {
      id: 'best-qr-generator-guide',
      title: language === 'ar' 
        ? 'أفضل طريقة لإنشاء رموز QR احترافية مجانًا: دليلك لاستخدام PixoQR'
        : 'Best Way to Create Professional QR Codes for Free: Your Guide to Using PixoQR',
      excerpt: language === 'ar'
        ? 'تعلم كيفية إنشاء رموز QR احترافية باستخدام PixoQR مع نصائح متقدمة للتخصيص والاستخدام الأمثل'
        : 'Learn how to create professional QR codes using PixoQR with advanced customization tips and optimal usage',
      date: '2024-01-15',
      readTime: '5 دقائق'
    },
    {
      id: 'qr-marketing-sales',
      title: language === 'ar'
        ? 'كيف يمكن لرموز QR أن تُضاعف مبيعاتك؟ استخدم PixoQR بذكاء في التسويق'
        : 'How QR Codes Can Double Your Sales? Smart Marketing with PixoQR',
      excerpt: language === 'ar'
        ? 'اكتشف استراتيجيات التسويق المتقدمة باستخدام رموز QR وكيف تزيد مبيعاتك بطرق إبداعية'
        : 'Discover advanced marketing strategies using QR codes and how to increase sales with creative methods',
      date: '2024-01-10',
      readTime: '7 دقائق'
    },
    {
      id: 'smart-business-card',
      title: language === 'ar'
        ? 'بطاقة العمل الذكية: كيف تنشئ بطاقة تعريف احترافية برمز QR باستخدام PixoQR؟'
        : 'Smart Business Card: How to Create Professional QR Business Cards with PixoQR',
      excerpt: language === 'ar'
        ? 'دليل شامل لإنشاء بطاقات عمل رقمية احترافية تترك انطباعًا مميزًا لدى العملاء'
        : 'Complete guide to creating professional digital business cards that leave a lasting impression',
      date: '2024-01-05',
      readTime: '6 دقائق'
    },
    {
      id: 'best-qr-tools-2024',
      title: language === 'ar'
        ? 'أفضل أدوات تصميم QR Code مجانًا: دليلك الشامل لإنشاء رموز QR احترافية'
        : 'Best Free QR Code Design Tools: Complete Guide to Creating Professional QR Codes',
      excerpt: language === 'ar'
        ? 'مقارنة شاملة بين أفضل أدوات تصميم رموز QR المجانية مع نصائح الخبراء للاختيار الأمثل'
        : 'Comprehensive comparison of the best free QR code design tools with expert tips for optimal selection',
      date: '2023-12-28',
      readTime: '8 دقائق'
    },
    {
      id: 'choose-best-qr-generator-2025',
      title: language === 'ar'
        ? 'كيف تختار أفضل مولد QR Code لنشاطك التجاري؟ دليل شامل لعام 2025'
        : 'How to Choose the Best QR Code Generator for Your Business? Complete Guide for 2025',
      excerpt: language === 'ar'
        ? 'دليل متخصص لاختيار أفضل مولد رموز QR للشركات والأعمال التجارية مع معايير الاختيار المهنية'
        : 'Specialized guide for choosing the best QR code generator for companies and businesses with professional selection criteria',
      date: '2023-12-20',
      readTime: '10 دقائق'
    }
  ];

  return (
    <Layout>
      <div className="space-y-12">
        {/* Blog Header */}
        <div className="text-center space-y-6">
          <h1 className="text-4xl md:text-5xl font-display font-bold bg-qr-gradient bg-clip-text text-transparent">
            {t('blog.title')}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            {t('blog.description')}
          </p>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <Card 
              key={post.id}
              className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-2"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                  <Calendar className="h-4 w-4" />
                  <span>{new Date(post.date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}</span>
                  <span>•</span>
                  <span>{post.readTime}</span>
                </div>
                <CardTitle className="text-xl leading-tight group-hover:text-primary transition-colors">
                  {post.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  {post.excerpt}
                </p>
                <Link to={`/blog/${post.id}`}>
                  <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    {t('read.more')}
                    <ArrowLeft className={`h-4 w-4 ${language === 'ar' ? 'mr-2' : 'ml-2'}`} />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default BlogIndex;