import Layout from '@/components/Layout';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { MessageCircle, Shield, Zap, Download, Palette, Globe } from 'lucide-react';

const FAQ = () => {
  const { language } = useLanguage();

  const faqs = language === 'ar' ? [
    {
      question: "ما هي خدمة PixoQR؟",
      answer: "PixoQR هي أداة مجانية وسهلة الاستخدام لتحويل الروابط والنصوص إلى رموز QR قابلة للمشاركة والطباعة بجودة عالية."
    },
    {
      question: "هل يمكنني تخصيص تصميم رمز QR؟",
      answer: "نعم! يمكنك تخصيص الألوان، الأنماط، وإضافة شعارك الخاص لجعل رمز QR يتناسب مع هويتك التجارية."
    },
    {
      question: "هل أداة PixoQR آمنة؟",
      answer: "نعم، تمامًا آمنة. نحن لا نخزن أي روابط أو بيانات مدخلة، ويتم إنشاء رمز QR مباشرة على متصفحك دون إرسال المعلومات لخوادمنا."
    },
    {
      question: "هل الخدمة مجانية؟",
      answer: "نعم، الخدمة مجانية تمامًا للاستخدام الشخصي والتجاري بدون حدود أو علامات مائية."
    },
    {
      question: "ما هي صيغ التحميل المتاحة؟",
      answer: "يمكنك تحميل رموز QR بصيغة PNG عالية الجودة، مع خطط لإضافة صيغة SVG قريباً."
    },
    {
      question: "هل يعمل الموقع على الهواتف المحمولة؟",
      answer: "نعم، الموقع مصمم ليعمل بسلاسة على جميع الأجهزة - الكمبيوتر، التابلت، والهواتف الذكية."
    }
  ] : [
    {
      question: "What is PixoQR?",
      answer: "PixoQR is a free and easy-to-use tool for converting links and text into high-quality, shareable and printable QR codes."
    },
    {
      question: "Can I customize my QR code design?",
      answer: "Yes! You can customize colors, styles, and add your own logo to make the QR code match your brand identity."
    },
    {
      question: "Is PixoQR secure?",
      answer: "Absolutely secure. We don't store any entered links or data. QR codes are generated directly in your browser without sending information to our servers."
    },
    {
      question: "Is the service free?",
      answer: "Yes, the service is completely free for personal and commercial use with no limits or watermarks."
    },
    {
      question: "What download formats are available?",
      answer: "You can download QR codes in high-quality PNG format, with plans to add SVG format soon."
    },
    {
      question: "Does the website work on mobile devices?",
      answer: "Yes, the website is designed to work seamlessly on all devices - desktop, tablet, and smartphones."
    }
  ];

  return (
    <Layout>
      <div className="space-y-16">
        {/* Hero Section */}
        <div className="text-center space-y-6 animate-fade-in-up">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-qr-gradient rounded-2xl flex items-center justify-center shadow-lg">
              <MessageCircle className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-display font-bold bg-qr-gradient bg-clip-text text-transparent leading-tight">
            {language === 'ar' ? 'الأسئلة الشائعة' : 'Frequently Asked Questions'}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            {language === 'ar' 
              ? 'تعرف على إجابات أهم الأسئلة حول أداة تحويل الروابط إلى QR، كيفية الاستخدام، الأمان، والدعم الفني.'
              : 'Find answers to the most common questions about our QR code generator, usage, security, and technical support.'
            }
          </p>
        </div>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-glass-border rounded-lg px-6 py-2 bg-glass backdrop-blur-sm"
              >
                <AccordionTrigger className="text-left text-lg font-semibold hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pt-2">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          {[
            {
              icon: Shield,
              title: language === 'ar' ? 'آمن ومجاني' : 'Secure & Free',
              description: language === 'ar' ? 'خصوصية كاملة وبدون تكلفة' : 'Complete privacy at no cost'
            },
            {
              icon: Zap,
              title: language === 'ar' ? 'سريع وبسيط' : 'Fast & Simple',
              description: language === 'ar' ? 'إنشاء فوري بنقرة واحدة' : 'Instant generation with one click'
            },
            {
              icon: Palette,
              title: language === 'ar' ? 'قابل للتخصيص' : 'Customizable',
              description: language === 'ar' ? 'تصميمات تناسب علامتك التجارية' : 'Designs that match your brand'
            }
          ].map((feature, index) => (
            <Card 
              key={index}
              className="border-0 shadow-md hover:shadow-lg transition-all duration-300 backdrop-blur-sm bg-glass border border-glass-border text-center"
            >
              <CardHeader>
                <div className="w-12 h-12 bg-qr-gradient rounded-lg flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-lg font-display">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center space-y-6 py-12">
          <h3 className="text-2xl font-display font-bold">
            {language === 'ar' ? 'ما زلت تحتاج مساعدة؟' : 'Still need help?'}
          </h3>
          <p className="text-muted-foreground">
            {language === 'ar' 
              ? 'لا تتردد في التواصل معنا للحصول على الدعم الفني'
              : "Don't hesitate to contact us for technical support"
            }
          </p>
          <a 
            href="/contact" 
            className="inline-block bg-primary text-primary-foreground px-8 py-3 rounded-full font-semibold hover:bg-primary/90 transition-colors"
          >
            {language === 'ar' ? 'تواصل معنا' : 'Contact Us'}
          </a>
        </div>
      </div>
    </Layout>
  );
};

export default FAQ;