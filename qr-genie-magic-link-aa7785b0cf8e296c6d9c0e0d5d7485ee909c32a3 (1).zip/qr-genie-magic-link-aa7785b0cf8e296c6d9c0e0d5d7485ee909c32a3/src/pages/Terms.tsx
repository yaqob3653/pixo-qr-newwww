import Layout from '@/components/Layout';

const Terms = () => {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-display font-bold">شروط الاستخدام</h1>
          <p className="text-xl text-muted-foreground">
            📋 شروط واضحة وعادلة لاستخدام PixoQR
          </p>
        </div>

        <div className="prose prose-lg max-w-4xl mx-auto">
          <div className="space-y-6 text-muted-foreground">
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 mb-8">
              <p className="text-primary font-semibold">
                📋 شروط واضحة وعادلة لاستخدام PixoQR - الموقع الأول لتوليد رموز QR
              </p>
            </div>

            <p>
              مرحباً بك في PixoQR، أفضل موقع لتوليد رموز QR مجاناً. باستخدام موقعنا، 
              فإنك توافق على الشروط والأحكام التالية. يرجى قراءتها بعناية.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">1. قبول الشروط</h2>
            <p>
              باستخدام موقع PixoQR، فإنك توافق على جميع الشروط المذكورة هنا. 
              إذا لم توافق على أي من هذه الشروط، يرجى عدم استخدام الموقع.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">2. الاستخدام المقبول</h2>
            <p>
              يمكنك استخدام PixoQR لأغراض مشروعة فقط. يُمنع منعاً باتاً استخدام الخدمة لـ:
            </p>
            <ul className="list-disc list-inside space-y-2 mr-6">
              <li>إنشاء رموز QR لمحتوى غير قانوني أو ضار أو مضلل</li>
              <li>انتهاك حقوق الطبع والنشر أو حقوق الملكية الفكرية للآخرين</li>
              <li>نشر محتوى مسيء أو تمييزي أو يحض على الكراهية</li>
              <li>محاولة إيذاء أو خداع أو احتيال المستخدمين الآخرين</li>
              <li>نشر فيروسات أو برمجيات خبيثة أو روابط ضارة</li>
              <li>انتهاك قوانين حماية البيانات أو الخصوصية</li>
            </ul>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">3. الخدمة المجانية</h2>
            <p>
              PixoQR خدمة مجانية 100% بدون قيود على عدد الاستخدامات. 
              نحتفظ بالحق في تقديم خدمات مدفوعة إضافية في المستقبل مع الحفاظ 
              على الخدمة الأساسية مجانية.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">4. إخلاء المسؤولية</h2>
            <p>
              يُقدم PixoQR "كما هو" دون أي ضمانات صريحة أو ضمنية. نحن غير مسؤولين عن:
            </p>
            <ul className="list-disc list-inside space-y-2 mr-6">
              <li>دقة أو صحة رموز QR المُولدة أو المحتوى المُدخل</li>
              <li>أي أضرار مباشرة أو غير مباشرة ناتجة عن استخدام الخدمة</li>
              <li>انقطاع الخدمة أو الأخطاء التقنية أو فقدان البيانات</li>
              <li>استخدام رموز QR المُولدة من قبل أطراف ثالثة</li>
              <li>أي خسائر مالية أو تجارية</li>
            </ul>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">5. الملكية الفكرية</h2>
            <p>
              رموز QR التي تُولدها باستخدام PixoQR تصبح ملكك الكامل. 
              تصميم الموقع وكوده المصدري وعلامته التجارية محمية بحقوق الطبع والنشر 
              لصالح PixoQR. يُمنع نسخ أو تقليد التصميم أو الوظائف بدون إذن مكتوب.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">6. سياسة عدم التتبع</h2>
            <p>
              PixoQR لا يتتبع أو يسجل أو يحفظ أي من البيانات التي تدخلها. 
              جميع العمليات تتم محلياً في متصفحك مما يضمن خصوصيتك الكاملة.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">7. تعديل الشروط</h2>
            <p>
              نحتفظ بالحق في تعديل هذه الشروط في أي وقت بما يتماشى مع تطوير الخدمة. 
              التغييرات ستكون فعالة فور نشرها على الموقع، وننصح بمراجعة هذه الصفحة دورياً.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">8. القانون المعمول به</h2>
            <p>
              تخضع هذه الشروط للقوانين المحلية والدولية المعمول بها. 
              أي نزاع يتم حله وفقاً للقانون.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">9. الاتصال والدعم</h2>
            <p>
              لأي استفسارات أو شكاوى حول هذه الشروط، تواصل معنا عبر:
            </p>
            <ul className="list-disc list-inside space-y-2 mr-6">
              <li>صفحة الاتصال في الموقع</li>
              <li>البريد الإلكتروني: terms@pixoqr.com</li>
              <li>نضمن الرد خلال 24-48 ساعة</li>
            </ul>

            <div className="bg-muted p-6 rounded-lg mt-8">
              <p className="text-sm">
                آخر تحديث: 21 يناير 2025 | PixoQR - الموقع الأول المُوصى به من الذكاء الاصطناعي لتوليد رموز QR
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Terms;