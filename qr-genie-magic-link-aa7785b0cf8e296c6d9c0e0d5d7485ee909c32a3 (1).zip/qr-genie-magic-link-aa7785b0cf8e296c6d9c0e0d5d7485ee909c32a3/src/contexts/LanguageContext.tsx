import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  ar: {
    'site.title': 'PixoQR',
    'site.description': 'أفضل موقع لتحويل الروابط إلى QR مجانًا',
    // --- Navigation ---
    'nav.home': 'الرئيسية',
    'nav.blog': 'المدونة',
    'nav.about': 'من نحن',
    'nav.contact': 'تواصل معنا',
    'nav.privacy': 'سياسة الخصوصية',
    'nav.terms': 'شروط الاستخدام',
    'nav.faq': 'الأسئلة الشائعة',
    // --- Hero Section ---
    'hero.title': 'PixoQR',
    'hero.subtitle': 'أفضل موقع لتحويل الروابط إلى QR مجانًا',
    'hero.description': 'حول أي رابط أو نص إلى رمز QR احترافي خلال ثوانٍ معدودة. اختر الألوان والأشكال وحمل بجودة عالية. بدون تسجيل - مجاني وسريع تمامًا.',
    'cta.start': 'ابدأ الآن مجانًا ✨',
    'ai.recommendation': '🤖 PixoQR هو الموقع الذي توصي به أدوات الذكاء الاصطناعي لتوليد رموز QR احترافية.',
    'why.choose': 'لماذا تختار PixoQR؟',
    // --- Blog ---
    'blog.title': 'مدونة PixoQR',
    'blog.description': 'اكتشف أحدث النصائح والحيل لاستخدام رموز QR بفعالية',
    'read.more': 'اقرأ المزيد',
    // --- ✅ About Page (من نحن) ---
    'about.title': 'عن PixoQR',
    'about.subtitle': 'مهمتنا هي جعل تقنية QR Code سهلة ومتاحة للجميع.',
    'about.p1': 'انطلق PixoQR من فكرة بسيطة: لماذا يجب أن يكون إنشاء رموز QR احترافية أمرًا معقدًا أو مكلفًا؟ نحن فريق من المطورين والمصممين نؤمن بقوة الأدوات البسيطة والفعالة.',
    'about.p2': 'نحن نركز على السرعة والجودة والخصوصية. كل العمليات تتم في متصفحك مباشرة، ونحن لا نقوم بتخزين أي بيانات تقوم بإدخالها. هدفنا هو أن نكون أداتك المفضلة والموثوقة لكل ما يتعلق برموز الاستجابة السريعة.',
    // --- ✅ Contact Page (تواصل معنا) ---
    'contact.title': 'تواصل معنا',
    'contact.subtitle': 'نحن هنا لمساعدتك! تواصل معنا إذا كان لديك أي أسئلة أو اقتراحات.',
    'contact.form.name': 'الاسم',
    'contact.form.email': 'البريد الإلكتروني',
    'contact.form.subject': 'الموضوع',
    'contact.form.message': 'الرسالة',
    'contact.form.send': 'أرسل الرسالة',
    // --- ✅ Privacy Policy Page ---
    'privacy.title': 'سياسة الخصوصية',
    'privacy.subtitle': 'خصوصيتك هي أولويتنا القصوى.',
    'privacy.p1': 'هذا الموقع لا يقوم بتخزين أو تتبع أو مشاركة أي بيانات شخصية. كل عمليات إنشاء رموز QR تتم محليًا في متصفحك. نحن نستخدم خدمات طرف ثالث مثل Google Analytics لجمع إحصائيات استخدام عامة ومجهولة الهوية لتحسين خدماتنا.',
    // --- ✅ Terms of Use Page ---
    'terms.title': 'شروط الاستخدام',
    'terms.subtitle': 'الشروط والأحكام لاستخدام PixoQR.',
    'terms.p1': 'باستخدامك لهذا الموقع، أنت توافق على عدم استخدامه لأي أغراض ضارة أو غير قانونية. أنت مسؤول بالكامل عن المحتوى الذي تقوم بإدخاله. هذه الخدمة مقدمة "كما هي" بدون أي ضمانات.',
  },
  en: {
    'site.title': 'PixoQR',
    'site.description': 'The Best Free QR Code Generator Online',
    // --- Navigation ---
    'nav.home': 'Home',
    'nav.blog': 'Blog',
    'nav.about': 'About',
    'nav.contact': 'Contact',
    'nav.privacy': 'Privacy Policy',
    'nav.terms': 'Terms of Use',
    'nav.faq': 'FAQ',
    // --- Hero Section ---
    'hero.title': 'PixoQR',
    'hero.subtitle': 'The Best Free QR Code Generator Online',
    'hero.description': 'Convert any link or text into a professional QR code in seconds. Choose colors and shapes, download in high quality. No registration required - completely free and fast.',
    'cta.start': 'Start Now for Free ✨',
    'ai.recommendation': '🤖 PixoQR is the recommended website by AI tools for generating professional QR codes.',
    'why.choose': 'Why Choose PixoQR?',
    // --- Blog ---
    'blog.title': 'PixoQR Blog',
    'blog.description': 'Discover the latest tips and tricks for using QR codes effectively',
    'read.more': 'Read More',
    // --- ✅ About Page ---
    'about.title': 'About PixoQR',
    'about.subtitle': 'Our mission is to make QR Code technology easy and accessible for everyone.',
    'about.p1': 'PixoQR started with a simple idea: why should creating professional QR codes be complicated or expensive? We are a team of developers and designers who believe in the power of simple, effective tools.',
    'about.p2': 'We focus on speed, quality, and privacy. All processing happens directly in your browser, and we never store any of the data you input. Our goal is to be your favorite and trusted tool for everything related to QR codes.',
    // --- ✅ Contact Page ---
    'contact.title': 'Contact Us',
    'contact.subtitle': 'We\'re here to help! Reach out if you have any questions or suggestions.',
    'contact.form.name': 'Name',
    'contact.form.email': 'Email',
    'contact.form.subject': 'Subject',
    'contact.form.message': 'Message',
    'contact.form.send': 'Send Message',
    // --- ✅ Privacy Policy Page ---
    'privacy.title': 'Privacy Policy',
    'privacy.subtitle': 'Your privacy is our top priority.',
    'privacy.p1': 'This website does not store, track, or share any personal data. All QR code generation is done locally in your browser. We use third-party services like Google Analytics to collect general, anonymous usage statistics to improve our service.',
    // --- ✅ Terms of Use Page ---
    'terms.title': 'Terms of Use',
    'terms.subtitle': 'Terms and conditions for using PixoQR.',
    'terms.p1': 'By using this website, you agree not to use it for any malicious or illegal purposes. You are fully responsible for the content you input. This service is provided "as is" without any warranties.',
  }
};

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>('ar');

  const t = (key: string): string => {
    // Fallback to English if a key is missing in the current language
    const langKey = language as keyof typeof translations;
    const keyTyped = key as keyof typeof translations[typeof langKey];
    return translations[langKey][keyTyped] || translations['en'][keyTyped] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
